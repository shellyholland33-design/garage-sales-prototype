Garage Sales – PWA App
----------------------
1. Upload all files in this package (index.html, manifest.json, sw.js, icons/) to your GitHub repo root (same place as index.html).
2. Commit changes and refresh your GitHub Pages site.
3. On your phone, open your link. Add to Home Screen:
   - Android: Chrome menu → Add to Home Screen
   - iPhone: Safari Share → Add to Home Screen
4. The app will install with your Garage Sales icon and open full-screen.